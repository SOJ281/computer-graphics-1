#include "draw.hpp"

#include <algorithm>

#include <cmath>

#include "surface.hpp"

void draw_line_solid( Surface& aSurface, Vec2f aBegin, Vec2f aEnd, ColorU8_sRGB aColor ) {
	float inc = 1;
	Vec2f d = Vec2f{ aEnd.x - aBegin.x, aEnd.y - aBegin.y }; //length vector
	if (abs(d.x) > abs(d.y)) { //determines major length
		if (d.x < 0) //negative direction
			inc = -1;
		for (float x = floor(aBegin.x) + .5;
			!(x > aEnd.x + inc - 1 && x < aEnd.x + inc + 1); x += inc) {
			float y = ((x - aBegin.x) / d.x) * d.y + aBegin.y;
			if (0 <= x && x < aSurface.get_width()
				&& 0 <= y && y < aSurface.get_height())
				aSurface.set_pixel_srgb(x, y, aColor);
		}
	}
	else {
		if (d.y < 0) //negative direction
			inc = -1;
		for (float y = floor(aBegin.y) + .5;
			!(y > aEnd.y+inc - 1 && y < aEnd.y + inc + 1); y += inc) {
			float x = ((y - aBegin.y) / d.y) * d.x + aBegin.x;
			if (0 <= x && x < aSurface.get_width()
				&& 0 <= y && y < aSurface.get_height())
				aSurface.set_pixel_srgb(x, y, aColor);
		}
	}
}

void draw_triangle_wireframe( Surface& aSurface, Vec2f aP0, Vec2f aP1, Vec2f aP2, ColorU8_sRGB aColor )
{
	//TODO: your implementation goes here
	//TODO: your implementation goes here
	//TODO: your implementation goes here

	//TODO: remove the following when you start your implementation
	(void)aSurface; // Avoid warnings about unused arguments until the function
	(void)aP0;   // is properly implemented.
	(void)aP1;
	(void)aP2;
	(void)aColor;
}

//Code based on code found here:
//https://www.gamedev.net/forums/topic.asp?topic_id=295943
//Basically just returns the crossproduct
bool returnSign(Vec2f p0, Vec2f p1, Vec2f p2) {
	Vec2f u{ p0.x - p1.x, p0.y - p1.y };
	Vec2f v{ p0.x - p2.x, p0.y - p2.y };
	return (u.x * v.y - u.y * v.x) > 0;
}

//Struct to hold doubles
struct Vec2d {
	long double x;
	long double y;
};
//Calculates area of triangle
long double triAreaCalc(Vec2f p0, Vec2f p1, Vec2f p2) {
	Vec2d u{ p0.x - p1.x, p0.y - p1.y };
	Vec2d v{ p0.x - p2.x, p0.y - p2.y };
	return abs((u.x * v.y - u.y * v.x) / 2.0);
}

void lineDraw(Surface& aSurface, Vec2f aBegin, Vec2f aEnd, ColorU8_sRGB aColor) {
	Vec2f d = Vec2f{ aEnd.x - aBegin.x, aEnd.y - aBegin.y }; //length vector
	float c = sqrt(d.x * d.x + d.y * d.y) * 4;
	for (float i = 0; i < c; i++) {
		float x = aBegin.x + d.x * (i / c);
		float y = aBegin.y + d.y * (i / c);
		if (0 <= x && x < aSurface.get_width()
			&& 0 <= y && y < aSurface.get_height()) {
			aSurface.set_pixel_srgb(x, y, aColor);
		}
	}
}

void lineInterpol(Surface& aSurface, Vec2f aBegin, Vec2f aEnd, Vec2f aP2, ColorF aC0, ColorF aC1, ColorF aC2) {
	Vec2f d = Vec2f{ aEnd.x - aBegin.x, aEnd.y - aBegin.y }; //length vector
	float c = sqrt(d.x * d.x + d.y * d.y)*4;
	for (float i = 0; i < c; i++) {
		float x = aBegin.x + d.x * (i / c);
		float y = aBegin.y + d.y * (i / c);
		long double triArea = triAreaCalc(aBegin, aEnd, aP2);
		float b0 = triAreaCalc(Vec2f{ x,y }, aEnd, aP2) / triArea;
		float b1 = triAreaCalc(aBegin, Vec2f{ x,y }, aP2) / triArea;
		float b2 = triAreaCalc(aBegin, aEnd, Vec2f{ x,y }) / triArea;
		if (0 <= x && x < aSurface.get_width()
			&& 0 <= y && y < aSurface.get_height()) {
			aSurface.set_pixel_srgb(x, y,
				linear_to_srgb(ColorF{ aC0.r * b0 + aC1.r * b1 + aC2.r * b2
			,aC0.g * b0 + aC1.g * b1 + aC2.g * b2
			,aC0.b * b0 + aC1.b * b1 + aC2.b * b2 }));
		}
	}
}

void draw_triangle_solid( Surface& aSurface, Vec2f aP0, Vec2f aP1, Vec2f aP2, ColorU8_sRGB aColor ) {
	Vec2f smallest = aP0;
	if (aP1.x < smallest.x)
		smallest.x = aP1.x;
	if (aP2.x < smallest.x)
		smallest.x = aP2.x;
	if (aP1.y < smallest.y)
		smallest.y = aP1.y;
	if (aP2.y < smallest.y)
		smallest.y = aP2.y;
	Vec2f biggest = aP0;
	if (aP1.x > biggest.x)
		biggest.x = aP1.x;
	if (aP2.x > biggest.x)
		biggest.x = aP2.x;
	if (aP1.y > biggest.y)
		biggest.y = aP1.y;
	if (aP2.y > biggest.y)
		biggest.y = aP2.y;

	if (biggest.x >= 0 && biggest.y >= 0) { // Won't draw if it won't show up
		//wireframe
		lineDraw(aSurface, aP0, aP1, aColor);
		lineDraw(aSurface, aP0, aP2, aColor);
		lineDraw(aSurface, aP1, aP2, aColor);
		Vec2f pt = Vec2f{ smallest.x ,smallest.y };
		for (pt.x = smallest.x; pt.x < biggest.x && pt.x < aSurface.get_width(); pt.x += 1) {
			for (pt.y = smallest.y; pt.y < biggest.y && pt.y < aSurface.get_height(); pt.y += 1) {
				//Code based on code found here:
				//https://www.gamedev.net/forums/topic.asp?topic_id=295943
				bool b0 = returnSign(pt, aP1, aP2);
				bool b1 = returnSign(aP0, pt, aP2);
				bool b2 = returnSign(aP0, aP1, pt);

				if((b0 == b1 && b1 == b2) && 0 <= pt.x && 0 <= pt.y)
					aSurface.set_pixel_srgb(pt.x, pt.y, aColor);
			}
		}
	}
}


void draw_triangle_interp(Surface& aSurface, Vec2f aP0, Vec2f aP1, Vec2f aP2, ColorF aC0, ColorF aC1, ColorF aC2) {
	//Finds the smallest and largest coordinates
	Vec2f smallest = aP0;
	if (aP1.x < smallest.x)
		smallest.x = aP1.x;
	if (aP2.x < smallest.x)
		smallest.x = aP2.x;
	if (aP1.y < smallest.y)
		smallest.y = aP1.y;
	if (aP2.y < smallest.y)
		smallest.y = aP2.y;
	Vec2f biggest = aP0;
	if (aP1.x > biggest.x)
		biggest.x = aP1.x;
	if (aP2.x > biggest.x)
		biggest.x = aP2.x;
	if (aP1.y > biggest.y)
		biggest.y = aP1.y;
	if (aP2.y > biggest.y)
		biggest.y = aP2.y;

	if (biggest.x >= 0 && biggest.y >= 0) { // Won't draw if it won't show up at all
		//vectors relative to rectangle
		Vec2f rp0 = Vec2f{ aP0.x - smallest.x ,aP0.y - smallest.y };
		Vec2f rp1 = Vec2f{ aP1.x - smallest.x ,aP1.y - smallest.y };
		Vec2f rp2 = Vec2f{ aP2.x - smallest.x ,aP2.y - smallest.y };
		//Wireframe
		lineInterpol(aSurface, aP0, aP1, aP2, aC0, aC1, aC2);
		lineInterpol(aSurface, aP0, aP2, aP1, aC0, aC2, aC1);
		lineInterpol(aSurface, aP1, aP2, aP0, aC1, aC2, aC0);
		//vector point
		Vec2f pt = Vec2f{ smallest.x ,smallest.y };
		for (pt.x = smallest.x; pt.x < biggest.x && pt.x < aSurface.get_width(); pt.x += 1) {
			for (pt.y = smallest.y; pt.y < biggest.y && pt.y < aSurface.get_height(); pt.y += 1) {
				//point relative to rectangle
				Vec2f rpt = Vec2f{ pt.x - smallest.x ,pt.y - smallest.y };

				//Areas of triangles
				long double triArea = triAreaCalc(rp0, rp1, rp2);
				long double tb0 = floor(triAreaCalc(rpt, rp1, rp2));
				long double tb1 = floor(triAreaCalc(rp0, rpt, rp2));
				long double tb2 = floor(triAreaCalc(rp0, rp1, rpt));

				if ((tb0 + tb1 + tb2 <= triArea) && 0 <= pt.x && 0 <= pt.y) {
					//barycentric coordinates
					float b0 = (tb0 / triArea);
					float b1 = (tb1 / triArea);
					float b2 = (tb2 / triArea);
					aSurface.set_pixel_srgb(pt.x, pt.y,
						linear_to_srgb(ColorF{ aC0.r * b0 + aC1.r * b1 + aC2.r * b2
					,aC0.g * b0 + aC1.g * b1 + aC2.g * b2
					,aC0.b * b0 + aC1.b * b1 + aC2.b * b2 }));
				}
			}
		}
	}
}


void draw_rectangle_solid( Surface& aSurface, Vec2f aMinCorner, Vec2f aMaxCorner, ColorU8_sRGB aColor )
{
	//TODO: your implementation goes here
	//TODO: your implementation goes here
	//TODO: your implementation goes here

	//TODO: remove the following when you start your implementation
	(void)aSurface; // Avoid warnings about unused arguments until the function
	(void)aMinCorner;   // is properly implemented.
	(void)aMaxCorner;
	(void)aColor;
}

void draw_rectangle_outline( Surface& aSurface, Vec2f aMinCorner, Vec2f aMaxCorner, ColorU8_sRGB aColor )
{
	//TODO: your implementation goes here
	//TODO: your implementation goes here
	//TODO: your implementation goes here

	//TODO: remove the following when you start your implementation
	(void)aSurface; // Avoid warnings about unused arguments
	(void)aMinCorner;
	(void)aMaxCorner;
	(void)aColor;
}
