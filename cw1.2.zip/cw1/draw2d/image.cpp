#include "image.hpp"

#include <memory>
#include <algorithm>

#include <cstdio>
#include <cassert>

#include <stb_image.h>

#include "surface.hpp"

#include "../support/error.hpp"

namespace
{
	struct STBImageRGBA_ : public ImageRGBA
	{
		STBImageRGBA_( std::size_t, std::size_t, std::uint8_t* );
		virtual ~STBImageRGBA_();
	};
}

ImageRGBA::ImageRGBA()
	: mWidth( 0 )
	, mHeight( 0 )
	, mData( nullptr )
{}

ImageRGBA::~ImageRGBA() = default;


std::unique_ptr<ImageRGBA> load_image( char const* aPath )
{
	assert( aPath );

	stbi_set_flip_vertically_on_load( true );

	int w, h, channels;
	stbi_uc* ptr = stbi_load( aPath, &w, &h, &channels, 4 );
	if( !ptr )
		throw Error( "Unable to load image \"%s\"", aPath );

	return std::make_unique<STBImageRGBA_>(
		std::size_t(w),
		std::size_t(h),
		ptr
	);
}

void blit_masked( Surface& aSurface, ImageRGBA const& aImage, Vec2f aPosition ) {
	for (float x = aPosition.x; x < aImage.get_width() + aPosition.x && x < aSurface.get_width(); x += 1) {
		for (float y = aPosition.y; y < aImage.get_height() + aPosition.y && y < aSurface.get_height(); y += 1) {
			if (0 <= x && 0 <= y) {
				ColorU8_sRGB_Alpha pix = aImage.get_pixel(x- aPosition.x, y- aPosition.y);
				if (pix.a >= 128)
					aSurface.set_pixel_srgb(x, y, ColorU8_sRGB{ pix.r, pix.g, pix.b });
			}
		}
	}
}

namespace
{
	STBImageRGBA_::STBImageRGBA_( std::size_t aWidth, std::size_t aHeight, std::uint8_t* aPtr )
	{
		mWidth = aWidth;
		mHeight = aHeight;
		mData = aPtr;
	}

	STBImageRGBA_::~STBImageRGBA_()
	{
		if( mData )
			stbi_image_free( mData );
	}
}
