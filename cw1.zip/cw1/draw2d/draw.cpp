#include "draw.hpp"

#include <algorithm>

#include <cmath>

#include "surface.hpp"

void draw_line_solid( Surface& aSurface, Vec2f aBegin, Vec2f aEnd, ColorU8_sRGB aColor ) {
	float xLength = aEnd.x - aBegin.x;
	float yLength = aEnd.y - aBegin.y;
	float gradient = yLength / xLength;
	//float c = sqrt(xLength * xLength + yLength * yLength);

	//printf("c = %lf", c);
	//printf("startx = %lf\n", aBegin.x);
	//printf("endx = %lf\n", aEnd.x);

	float inc = 1;
	Vec2f d;
	d.x = xLength;
	d.y = yLength;
	if (xLength * xLength > yLength * yLength) {
		if (xLength < 0)
			inc = -1;
		//for (float x = aBegin.x; x*x < aEnd.x * aEnd.x; x += inc) {
		for (float x = aBegin.x; !(x > aEnd.x - 1 && x < aEnd.x + 1); x += inc) {
			float y = ((x - aBegin.x) / d.x) * d.y + aBegin.y;
			if (0 <= x && x < aSurface.get_width() - 1
				&& 0 <= y && y < aSurface.get_height() - 1)
				aSurface.set_pixel_srgb(x, y, aColor);
		}
	}
	else {
		if (yLength < 0)
			inc = -1;
		//for (float y = aBegin.y; y*y < aEnd.y * aEnd.y; y += inc) {
		for (float y = aBegin.y; !(y > aEnd.y - 1 && y < aEnd.y + 1); y += inc) {
			float x = ((y - aBegin.y) / d.y) * d.x + aBegin.x;
			if (0 <= x && x < aSurface.get_width() - 1
				&& 0 <= y && y < aSurface.get_height() - 1)
				aSurface.set_pixel_srgb(x, y, aColor);
		}
	}
	/*
	while (current.x*current.x < aEnd.x*aEnd.x) {
		current += d * .1;
		if (major)
			float y = ((x - aBegin.x) / d.x) * d.y + aBegin.y;
		if (0 <= current.x && current.x < aSurface.get_width() - 1
			&& 0 <= current.y && current.y < aSurface.get_height() - 1)
			aSurface.set_pixel_srgb(current.x, current.y, aColor);
	}





	Vec2f d;
	d.x = xLength / c;
	d.y = yLength / c;
	Vec2f current = aBegin;
	
	std::size_t x = -1, y = -1;

	for (float pos = 0; pos < c; pos += .1) {
		current += d*.1;
		//printf("x = %lf\n", current.x);
		//current.x = floor(current.x);
		//current.y = floor(current.y);
		if (0 <= current.x && current.x < aSurface.get_width() - 1
			&& 0 <= current.y && current.y < aSurface.get_height() - 1)
			aSurface.set_pixel_srgb(current.x, current.y, aColor);
	}*/


	/*

	float xLength = aEnd.x - aBegin.x;
	float yLength = aEnd.y - aBegin.y;

	float c = sqrt(xLength * xLength + yLength * yLength);


	int major = 0;
	Vec2f d;
	float mLength;
	if (xLength > yLength) {
		mLength = sqrt(xLength * xLength);
		d.x = xLength / mLength;
		d.y = yLength / mLength;
		major = 0;
	} else {
		mLength = sqrt(yLength * yLength);
		d.x = xLength / mLength;
		d.y = yLength / mLength;
		major = 1;
	}
	Vec2f current = aBegin;
	std::size_t x = -1, y = -1;

	for (float pos = 0; pos < mLength; pos += .1) {
		current += d * .1;
		if (0 <= current.x && current.x < aSurface.get_width() - 1
			&& 0 <= current.y && current.y < aSurface.get_height() - 1)
			aSurface.set_pixel_srgb(current.x, current.y, aColor);
	}*/

}

void draw_triangle_wireframe( Surface& aSurface, Vec2f aP0, Vec2f aP1, Vec2f aP2, ColorU8_sRGB aColor )
{
	//TODO: your implementation goes here
	//TODO: your implementation goes here
	//TODO: your implementation goes here

	//TODO: remove the following when you start your implementation
	(void)aSurface; // Avoid warnings about unused arguments until the function
	(void)aP0;   // is properly implemented.
	(void)aP1;
	(void)aP2;
	(void)aColor;
}

struct Vec2d {
	long double x;
	long double y;
};

long double triAreaCalc(Vec2f P0, Vec2f P1, Vec2f P2) {
	Vec2d u{ P0.x - P1.x, P0.y - P1.y };
	Vec2d v{ P0.x - P2.x, P0.y - P2.y };
	long double area = (u.x * v.y - u.y * v.x) / 2.0;
	if (area < 0)
		return -area;
	return area;

}
float sign(Vec2d p1, Vec2d p2, Vec2d p3)
{
	return (p1.x - p3.x) * (p2.y - p3.y) - (p2.x - p3.x) * (p1.y - p3.y);
}

bool PointInTriangle(Vec2f pti, Vec2f v1i, Vec2f v2i, Vec2f v3i) {
	long double d1, d2, d3;
	bool has_neg, has_pos;
	Vec2d pt{ pti.x, pti.y };
	Vec2d v1{ v1i.x, v1i.y };
	Vec2d v2{ v2i.x, v2i.y };
	Vec2d v3{ v3i.x, v3i.y };;

	d1 = sign(pt, v1, v2);
	d2 = sign(pt, v2, v3);
	d3 = sign(pt, v3, v1);

	has_neg = (d1 < 0) || (d2 < 0) || (d3 < 0);
	has_pos = (d1 > 0) || (d2 > 0) || (d3 > 0);

	return !(has_neg && has_pos);
}

void draw_triangle_solid( Surface& aSurface, Vec2f aP0, Vec2f aP1, Vec2f aP2, ColorU8_sRGB aColor ) {
	/*
	float axLength = aP0.x - aP1.x;
	float ayLength = aP0.y - aP1.y;
	float ac = sqrt(axLength * axLength + ayLength * ayLength);

	float bxLength = aP2.x - aP1.x;
	float byLength = aP2.y - aP1.y;
	float bc = sqrt(bxLength * bxLength + byLength * byLength);


	Vec2f ad;
	Vec2f bd;

	if (ac > bc) {
		ad.x = axLength / ac;
		ad.y = ayLength / ac;
		bd.x = bxLength / ac;
		bd.y = byLength / ac;
	} else {
		ad.x = axLength / bc;
		ad.y = ayLength / bc;
		bd.x = bxLength / bc;
		bd.y = byLength / bc;
	}


	Vec2f acurrent = aP1;
	Vec2f bcurrent = aP1;

	for (float pos = 0; pos < ac; pos += 1) {
		acurrent += ad;
		bcurrent += bd;
		if ( 0 <= acurrent.x && acurrent.x < aSurface.get_width() - 1
			&& 0 <= acurrent.y && acurrent.y < aSurface.get_height() - 1
			&& 0 <= bcurrent.x && bcurrent.x < aSurface.get_width() - 1
			&& 0 <= bcurrent.y && bcurrent.y < aSurface.get_height() - 1)
			draw_line_solid(aSurface, acurrent, bcurrent, aColor);
	}*/
	Vec2f smallest = aP0;
	if (aP1.x < smallest.x)
		smallest.x = aP1.x;
	if (aP2.x < smallest.x)
		smallest.x = aP2.x;
	if (aP1.y < smallest.y)
		smallest.y = aP1.y;
	if (aP2.y < smallest.y)
		smallest.y = aP2.y;
	Vec2f biggest = aP0;
	if (aP1.x > biggest.x)
		biggest.x = aP1.x;
	if (aP2.x > biggest.x)
		biggest.x = aP2.x;
	if (aP1.y > biggest.y)
		biggest.y = aP1.y;
	if (aP2.y > biggest.y)
		biggest.y = aP2.y;

	Vec2f pt = Vec2f{ smallest.x ,smallest.y };
	for (pt.x = smallest.x; pt.x < biggest.x; pt.x += 1) {
		for (pt.y = smallest.y; pt.y < biggest.y; pt.y += 1) {
			float TotalArea = triAreaCalc(aP0, aP1, aP2);
			float Area1 = triAreaCalc(pt, aP1, aP2);
			float Area2 = triAreaCalc(pt, aP0, aP2);
			float Area3 = triAreaCalc(pt, aP0, aP1);
			if (Area1 + Area2 + Area3 <= TotalArea && 0 <= pt.x && pt.x < aSurface.get_width()
				&& 0 <= pt.y && pt.y < aSurface.get_height())
				aSurface.set_pixel_srgb(pt.x, pt.y, aColor);
		}
	}
}

void draw_triangle_interp(Surface& aSurface, Vec2f aP0, Vec2f aP1, Vec2f aP2, ColorF aC0, ColorF aC1, ColorF aC2 ) {
	//draw_triangle_solid(aSurface, aP0, aP1, aP2, linear_to_srgb(aC0));

	//Finds the smallest and largest coordinates
	
	Vec2f smallest = aP0;
	if (aP1.x < smallest.x)
		smallest.x = aP1.x;
	if (aP2.x < smallest.x)
		smallest.x = aP2.x;
	if (aP1.y < smallest.y)
		smallest.y = aP1.y;
	if (aP2.y < smallest.y)
		smallest.y = aP2.y;
	Vec2f biggest = aP0;
	if (aP1.x > biggest.x)
		biggest.x = aP1.x;
	if (aP2.x > biggest.x)
		biggest.x = aP2.x;
	if (aP1.y > biggest.y)
		biggest.y = aP1.y;
	if (aP2.y > biggest.y)
		biggest.y = aP2.y;

	Vec2f pt = Vec2f{ smallest.x ,smallest.y };
	for (pt.x = smallest.x-5; pt.x < biggest.x+5; pt.x += 1) {
		for (pt.y = smallest.y-5; pt.y < biggest.y+5; pt.y += 1) {
			long double triArea = triAreaCalc(aP0, aP1, aP2);
			long double b0 = triAreaCalc(pt, aP1, aP2);
			long double b1 = triAreaCalc(aP0, pt, aP2);
			long double b2 = triAreaCalc(aP0, aP1, pt);

			//printf("area = %lf\n", triArea);
			//bool bo1 = (Vec2f{ pt.x - aP1.x, pt.y - aP1.y } *Vec2f{ aP1.y - aP2.y, aP2.x - aP1.x } > 0);
			//bool bo2 = (Vec2f{ pt.x - aP2.x, pt.y - aP2.y } *Vec2f{ aP2.y - aP0.y, aP0.x - aP2.x } > 0);
			//if (PointInTriangle(pt, aP0, aP1, aP2) && 0 <= pt.x && pt.x < aSurface.get_width()
			//	&& 0 <= pt.y && pt.y < aSurface.get_height()) {
			if ((b0 + b1 + b2) <= triArea && 0 <= pt.x && pt.x < aSurface.get_width()
				&& 0 <= pt.y && pt.y < aSurface.get_height()) {
				float fb0 = b0 / triArea;
				float fb1 = b1 / triArea;
				float fb2 = b2 / triArea;
				//aSurface.set_pixel_srgb(pt.x, pt.y, linear_to_srgb(aC0));
				
				aSurface.set_pixel_srgb(pt.x, pt.y,
					linear_to_srgb(ColorF{ aC0.r * fb0 + aC1.r * fb1 + aC2.r * fb2
				,aC0.g * fb0 + aC1.g * fb1 + aC2.g * fb2
				,aC0.b * fb0 + aC1.b * fb1 + aC2.b * fb2 }));
			}
		}
	}


	/*
	float axLength = aP0.x - aP1.x;
	float ayLength = aP0.y - aP1.y;
	float ac = sqrt(axLength * axLength + ayLength * ayLength);

	float bxLength = aP2.x - aP1.x;
	float byLength = aP2.y - aP1.y;
	float bc = sqrt(bxLength * bxLength + byLength * byLength);


	Vec2f ad;
	Vec2f bd;

	float finale;

	if (ac > bc) {
		ad.x = axLength / ac;
		ad.y = ayLength / ac;
		bd.x = bxLength / ac;
		bd.y = byLength / ac;
		finale = ac;
	}
	else {
		ad.x = axLength / bc;
		ad.y = ayLength / bc;
		bd.x = bxLength / bc;
		bd.y = byLength / bc;
		finale = bc;
	}


	Vec2f acurrent = aP1;
	Vec2f bcurrent = aP1;

	float triArea = triAreaCalc(aP0, aP1, aP2);

	
	for (float pos = 0; pos < ac; pos += 1) {
		acurrent += ad;
		bcurrent += bd;

			float xLength = bcurrent.x - acurrent.x;
			float yLength = bcurrent.y - acurrent.y;

			float c = sqrt(xLength * xLength + yLength * yLength);


			Vec2f d;
			d.x = xLength / c;
			d.y = yLength / c;

			Vec2f current = acurrent;
			Vec2f pioneer = acurrent;
			std::size_t x = -1, y = - 1;

			for (float l = 0; l < c; l += .5) {
				current += d * .5;
				float b0 = triAreaCalc(current, aP1, aP2) / triArea;
				float b1 = triAreaCalc(aP0, current, aP2) / triArea;
				float b2 = triAreaCalc(aP0, aP1, current) / triArea;
				ColorF initCol = ColorF{ aC0.r*b0 + aC1.r * b1 + aC2.r * b2
					,aC0.g * b0 + aC1.g * b1 + aC2.g * b2
					,aC0.b * b0 + aC1.b * b1 + aC2.b * b2 };

				if (0 <= current.x && current.x < aSurface.get_width()
					&& 0 <= current.y && current.y < aSurface.get_height())
					aSurface.set_pixel_srgb(current.x, current.y, linear_to_srgb(initCol));
			}
	}
	*/
}


void draw_rectangle_solid( Surface& aSurface, Vec2f aMinCorner, Vec2f aMaxCorner, ColorU8_sRGB aColor )
{
	//TODO: your implementation goes here
	//TODO: your implementation goes here
	//TODO: your implementation goes here

	//TODO: remove the following when you start your implementation
	(void)aSurface; // Avoid warnings about unused arguments until the function
	(void)aMinCorner;   // is properly implemented.
	(void)aMaxCorner;
	(void)aColor;
}

void draw_rectangle_outline( Surface& aSurface, Vec2f aMinCorner, Vec2f aMaxCorner, ColorU8_sRGB aColor )
{
	//TODO: your implementation goes here
	//TODO: your implementation goes here
	//TODO: your implementation goes here

	//TODO: remove the following when you start your implementation
	(void)aSurface; // Avoid warnings about unused arguments
	(void)aMinCorner;
	(void)aMaxCorner;
	(void)aColor;
}
